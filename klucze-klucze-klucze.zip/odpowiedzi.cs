using System;

public class kluczOdpowiedzi {

public string[] odpowiedzi = new string[2];
public bool[] TrueFalse = new bool[2];

public kluczOdpowiedzi(string odpPtak, string odpMarka, bool tfPtak, bool tfMarka){
  odpowiedzi[0] = odpPtak;
  odpowiedzi[1] = odpMarka;
  TrueFalse[0]  = tfPtak;
  TrueFalse[1]  = tfMarka;
}

public int ilePunktow (kluczPtakow ptaki, kluczMetalowy metal){
  int k = 0;
  if (ptaki.gatunek == odpowiedzi[0] && TrueFalse[0] == true) k++;
  if (ptaki.gatunek != odpowiedzi[0] && TrueFalse[0] == false) k++;
  if (metal.marka == odpowiedzi[1] && TrueFalse[1] == true) k++;
  if (metal.marka != odpowiedzi[1] && TrueFalse[1] == false) k++;
  
  return k;
}

}
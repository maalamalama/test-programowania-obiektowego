using System;

public class kluczPtakow {

public int ilePtakow;
public string gatunek;

public kluczPtakow (string gat, int ile){
ilePtakow = ile;
gatunek = gat;
}
public void zmiana (kluczOdpowiedzi odpow){
  gatunek = odpow.odpowiedzi[0];
}

}
using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("klucz odpowiedzi zmienia nazwę gatunku ptaka w kluczu albo markę klucza do zamka");
    kluczOdpowiedzi odp = new kluczOdpowiedzi ("gęsi", "francuski", true, true);
  }
}
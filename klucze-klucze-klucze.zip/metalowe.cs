using System;

public class kluczMetalowy {

public string marka;
public string kolor;
public string jakiMetal;

public kluczMetalowy (string mar, string kol, string jaki){
  marka = mar;
  kolor = kol;
  jakiMetal = jaki;
}

public void zmiana (kluczOdpowiedzi odpow){
  marka = odpow.odpowiedzi[0];
}

}